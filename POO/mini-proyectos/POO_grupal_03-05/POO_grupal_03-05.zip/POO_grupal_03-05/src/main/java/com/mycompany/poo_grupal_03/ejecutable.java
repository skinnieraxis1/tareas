package com.mycompany.poo_grupal_03;

import java.util.Scanner;

/**
 *
 * @author CS-13
 */
public class ejecutable {
    
    public Scanner teclado = new Scanner(System.in);
    
    Empresa empresasita = crearEmpresa();
    mostrarClientesEmpresa(empresasita);

    public Empleado crearEmpleado(){
        System.out.println("Ingrese el nombre el empleado : ");
        String nombre = teclado.next();
        System.out.println("Ingrese la edad del empleado : ");
        int edad = teclado.nextInt();
        System.out.println("Ingrese el sueldo del empleado : ");
        double sueldoB = teclado.nextDouble();
        Empleado empleado = new Empleado(nombre, edad, sueldoB);
        return empleado;
    }
    public Cliente crearCliente(){
        System.out.println("Ingrese el nombre del Cliente : ");
        String nombre = teclado.next();
        System.out.println("Ingrese la edad del Cliente : ");
        int edad = teclado.nextInt();
        System.out.println("Ingrese el telefono del cliente : ");
        int telefono = teclado.nextInt();
        Cliente cliente = new Cliente(nombre, edad, telefono);
        return cliente;
    
    }
    public Empresa crearEmpresa(){
        System.out.println("Ingrese el nombre de la empresa: ");
        
        String n = teclado.next();
        
        System.out.println("Ingrese la cantidad de empleados (subordinados) que tiene la empresa: ");
        int cantE = teclado.nextInt();
        
        Empleado[] empleados = new Empleado[cantE];

        for(int i = 0; i <= cantE; i++){
            empleados[i] = crearEmpleado();
        }
        
        System.out.println("Ingrese la cantidad de directivos que tiene la empresa: ");
        cantE = teclado.nextInt();
        
        Directivo[] directivos = new Directivo[cantE];

        for(int i = 0; i <= cantE; i++){
            directivos[i] = crearDirectivo();
        }
        
        System.out.println("Ingrese la cantidad de clientes que tiene la empresa: ");
        cantE = teclado.nextInt();
        
        Cliente[] clientes = new Cliente[cantE];

        for(int i = 0; i <= cantE; i++){
            clientes[i] = crearCliente();
        }
        
        String c = teclado.next();
        Empresa empresa = new Empresa(n,empleados,clientes, directivos);
        return empresa;
        
        
    }
    public Directivo  crearDirectivo(){
        System.out.println("Ingrese el nombre del directivo : ");
        String nombre = teclado.next();
        System.out.println("Ingrese la edad del directivo : ");
        int edad = teclado.nextInt();
        System.out.println("Ingrese la categoria del directivo : ");
        String cat = teclado.next();
        Directivo directivo = new Directivo(nombre, edad, cat);
        return directivo;
    }
    
    public void mostrarClientesEmpresa(Empresa empresasita){
        
        Cliente[] clientes = empresasita.getClientes();
        Empleado[] empleados = empresasita.getEmpleados();
        Directivo[] directivos = empresasita.getDirectivos();
        
        for(int i = 0; i <= clientes.length; i++){
            System.out.println("A continuacion los clientes: ");
            clientes[i].mostrarDatos();
        }
        for(int i = 0; i <= empleados.length; i++){
            System.out.println("A continuacion los empleados: ");
            empleados[i].mostrarDatos();
        }
        for(int i = 0; i <= directivos.length; i++){
            System.out.println("A continuacion los directivos: ");
            directivos[i].mostrarDatos();
        }
        
    }
    
    
    
}

