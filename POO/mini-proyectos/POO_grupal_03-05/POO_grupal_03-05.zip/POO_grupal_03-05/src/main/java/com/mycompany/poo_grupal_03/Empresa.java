
package com.mycompany.poo_grupal_03;

public class Empresa {
    
    private String nombre;
    private Empleado[] empleados;
    private Cliente[] clientes;
    
    public Empresa(String n, Empleado[] e, Cliente[] c){
        this.nombre = n;
        this.empleados = e;
        this.clientes = c;
    }
    
}
