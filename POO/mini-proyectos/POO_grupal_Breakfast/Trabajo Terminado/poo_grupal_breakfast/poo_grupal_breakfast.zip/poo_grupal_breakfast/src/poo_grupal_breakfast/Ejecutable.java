package poo_grupal_breakfast;
import java.util.*;

public class Ejecutable {
    public static void main(String[] args) {
        Scanner key = new Scanner(System.in);
        Empleado per1 = new Empleado("Alicia", 1140976059, 95000.00);
        Empleado per2 = new Empleado("Pedro", 1140976050, 95000.00);
        Empleado per3 = new Empleado("Manuel", 1140976051, 95000.00);
        Empleado per4 = new Empleado("Ana", 1140976052, 95000.00);
        ArrayList<Empleado> empleados = new ArrayList();
        empleados.add(per1);
        empleados.add(per2);
        empleados.add(per3);
        empleados.add(per4);
        ArrayList<Cliente> clientes = new ArrayList();
        ArrayList<Pedido> pedidos = new ArrayList();
        String choice ="y";
        int numeroPedido=0;
        boolean t = false;
        while (choice.equalsIgnoreCase("y")){
            Cliente cli = crearCliente();
            for (Cliente c:clientes){
                if(c.getNumeroTel() == cli.getNumeroTel()){
                    c.setCantDesayunos(c.getCantDesayunos()+1);
                    t = true;
                }
            }
            if(t == false){
                clientes.add(cli);
            }
            t = false;
            ArrayList<Desayuno> desayuno=cargarDesayuno();
            System.out.println("numero de pedido? ");
            numeroPedido+=1; 
            cli.mostrarDatos();
            for (Desayuno d:desayuno){
                d.mostrarDatos();
            }
            Pedido pedid=new Pedido(cli,numeroPedido,desayuno);
            pedidos.add(pedid);
            System.out.println("desea crear otro pedido (y/n)");
            choice=key.next();
        }
        int x = 0;
        for(Pedido p:pedidos){
            x++;
            System.out.println("Pedido " + x);
            p.emitirTicket();
        }
    }
    
    public static Cliente crearCliente() {
        Scanner lector = new Scanner(System.in);
        Cliente cliente;
        System.out.println("Ingrese el nombre del cliente: ");
        //lector.nextLine();
        String nombre = lector.next();  
        System.out.println("Ingrese su numero de telefono: ");
        int numeroTel = lector.nextInt();
        int cantDesayunos = 1;
        cliente = new Cliente(nombre, numeroTel, cantDesayunos);
        return cliente;
    }
    
    public static ArrayList<Desayuno> cargarDesayuno(){
        Scanner l=new Scanner(System.in);
        System.out.println("cuantos desayunos pidio el cliente? ");
        int can=l.nextInt();
        ArrayList<Desayuno> desayunos=new ArrayList();
        for (int i = 0; i < can; i++) {
            System.out.println("cuantos ingredientes tiene el desayuno? ");
            int cant=l.nextInt();
            ArrayList<Ingrediente> ingredientes=new ArrayList();
            ingredientes=cargarIngredientes(cant);
            System.out.println("nombre del desayuno? ");
            String nombre=l.next();
            Desayuno desayuno=new Desayuno(nombre,ingredientes);
            desayunos.add(desayuno);
        }
        return desayunos;
    }
    public static ArrayList<Ingrediente> cargarIngredientes(int cant) {
        Scanner key=new Scanner(System.in);
        ArrayList<Ingrediente> ingred=new ArrayList();
        for (int i = 0; i < cant; i++) {
            System.out.println("Nombre del ingrediente? ");
            //key.nextLine();
            String nombre=key.next();
            System.out.println("Precio del ingrediente? ");
            double precio=key.nextDouble();
            ingred.add(new Ingrediente(nombre,precio));
        }
        return ingred;
    }
}
