//Montenegro
package poo_grupal_breakfast;

public class Ingrediente {
    private String nombre;
    private double precio;
    
    public Ingrediente(String n, double p){
        this.nombre = n;
        this.precio = p;
    }
    
    public void mostrarDatos(){
        System.out.print(this.nombre + " y su precio es de: " + this.precio);
    }

    public String getNombre() {
        return nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }
    
}
