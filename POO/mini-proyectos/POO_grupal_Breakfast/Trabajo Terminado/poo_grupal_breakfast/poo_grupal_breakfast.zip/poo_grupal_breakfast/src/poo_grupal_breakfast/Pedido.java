//Lautaro
package poo_grupal_breakfast;

import java.util.ArrayList;
import java.util.Iterator;


public class Pedido {
    
    private Cliente cliente;
    private int numeroPedido;
    private ArrayList<Desayuno> desayuno=new ArrayList();
    private double precioT ;

    public Pedido(Cliente c, int n, ArrayList<Desayuno> d){
        this.desayuno = d;
        this.precioT = calcularTotalPedido(d);
        this.cliente = c;
        this.numeroPedido = n;
        
    }
    
    public void emitirTicket(){
        System.out.println("Numero de pedido: " + this.numeroPedido + " pertenece a " + this.cliente + " que pidio: ");
        for (Desayuno de:this.desayuno){
           System.out.print(" -");
           System.out.println(de);
        }
        System.out.println("con un precio de $" + this.precioT);
    }
    
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getNumeroPedido() {
        return numeroPedido;
    }

    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

   

    public double getPrecioT() {
        return precioT;
    }

    public void setPrecioT(double precioT) {
        this.precioT = precioT;
    }

    private double calcularTotalPedido(ArrayList<Desayuno> d) {
        double cant=0.0;
        if (this.cliente.getCantDesayunos()<10){
            for (Desayuno de:d) {
                cant+=de.calcularPrecioT();
            }   
        }
        return cant;
    }
        
}
    
